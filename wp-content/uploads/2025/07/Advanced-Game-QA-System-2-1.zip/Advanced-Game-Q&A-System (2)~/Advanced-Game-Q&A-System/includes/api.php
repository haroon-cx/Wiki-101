<?php 

function merged_api_ui_shortcode() {
    ob_start();
    ?>

<style>
/* 🌈 ========== GLOBAL & WRAPPERS ========== */
.api-form-wrapper {
    display: none;
}

.api-form-wrapper h1 {
    margin-top: -9px;
    font-size: 32px;
    color: #c770fe;
}

.api-form-wrapper.show {
    display: block;
}

.api-cards-wrapper.hide {
    display: none;
}

/* ✅ ORIGINAL HEADING DESIGN PRESERVED */
.api-heading-wrapper {
    max-width: 1340px;
    font-family: 'Poppins', sans-serif;
}

.api-heading-title {
    font-size: 32px;
    color: #c770fe;
    margin-bottom: 20px;
    border-bottom: 1px solid gray;
    font-family: 'Poppins', sans-serif;
}

.api-heading-bar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-bottom: 8px;
}

.border-line {
    flex: 1;
}

.add-api-btn {
    background-color: #7e3af2;
    color: white;
    border: none;
    padding: 10px 22px;
    border-radius: 25px;
    font-weight: 500;
    font-size: 14px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.add-api-btn.hide {
    display: none !important;
}

.add-api-btn:hover {
    background-color: #6528e0;
}

/* ✅ CARD STYLES */

/* === FINAL CARD FIX === */
.api-card-container {
    background: linear-gradient(to right, #000000, #422a6f);
    border-radius: 14px;
    padding: 2rem;
    max-width: 1340px;
    color: #dfc6ff;
    margin-top: 20px;
    font-family: 'Poppins', sans-serif;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
    overflow: hidden;
}

.api-card-header {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 2rem;
}

.api-price-api-cost {
    background: linear-gradient(94deg, #34244c 0%, #2b223c 100%);
    border-radius: 10px;
    padding: 1rem 2rem;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 153px;
    gap: 2rem;
    color: #fff;
    flex: 1;
    min-width: 250px;
    max-width: 474px;
}

.api-price-section {
    flex: 1;
    text-align: center;
}

.label-with-icon {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    /* Gap between label and icon */
    margin-bottom: 10px;
}

.api-price-section .label {
    font-weight: 600;
    font-size: 14px;
    opacity: 0.75;
}

.copy-icon {
    cursor: pointer;
    margin: -12px 0 0 3px;
    transition: opacity 0.3s ease;
}

.copy-icon:hover {
    opacity: 0.6;
}

.api-price-section .value {
    font-weight: 700;
    font-size: 40px;
    color: #fff;
}

.api-price-section .label {
    display: block;
    font-weight: 600;
    font-size: 14px;
    opacity: 0.75;
    margin-bottom: 10px;
}

.api-price-section .value {
    font-weight: 700;
    font-size: 40px;
    color: #fff;
}

.api-provider-section {
    min-width: 160px;
    text-align: center;
}

.api-provider-section .api-info-label {
    display: block;
    font-weight: 600;
    opacity: 0.75;
    font-size: 14px;
    margin-bottom: 8px;
}

.api-provider-logo {
    width: 90px;
    height: auto;
    object-fit: contain;
}

/* === DETAILS BELOW === */
/* === DETAILS Toggle === */
.api-details {
    max-height: 0;
    overflow: hidden;
    opacity: 0;
    margin-top: 0;
    transition: all 0.35s ease-in-out;
}

.api-card-container.open .api-details {
    max-height: 1500px;
    /* enough to show full content */
    opacity: 1;
    margin-top: 2rem;
}

.api-info-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1.5rem 2rem;
}

.api-info-label {
    display: block;
    font-weight: 500;
    font-size: 14px;
    opacity: 0.6;
    margin-bottom: 4px;
}

.api-info-value {
    font-size: 16px;
    font-weight: 600;
    color: #fff;
    word-break: break-word;
}

.api-info-value a {
    color: #00b6ff;
    text-decoration: none;
}

.api-report-button {
    margin-top: 2rem;
    background: rgba(70, 70, 70, 0.3);
    border: none;
    color: #ddd;
    font-size: 0.875rem;
    font-weight: 600;
    border-radius: 50px;
    padding: 8px 16px;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: background 0.3s ease, color 0.3s ease;
}

.api-report-button:hover {
    background: rgba(100, 100, 100, 0.5);
    color: #ffffff;
}

.api-report-icon {
    width: 14px;
    height: 14px;
}



.back-button {
    display: inline-flex;
    align-items: center;
    font-size: 20px;
    color: #fff;
    border: 1.5px solid #a278e4;
    border-radius: 999px;
    padding: 6px 14px;
    cursor: pointer;
    margin-bottom: 1.8rem;
    background-color: transparent;
    font-family: 'Poppins', sans-serif;
}

.back-button svg {
    width: 30px;
    height: 30px;
}

form {
    background: linear-gradient(135deg, #252031, #7644CE);
    border-radius: 8px;
    padding: 2rem 2.5rem;
    color: #fff;
}

.grid-3 {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
    gap: 1rem 1.5rem;
    margin-bottom: 1.5rem;
}

input[type="text"],
select,
textarea {
    width: 100%;
    padding: 0.65em 1em;
    border-radius: 6px;
    border: none;
    font-size: 0.95rem;
    background: #7a7a7a;
    color: #ddd;
}

textarea {
    min-height: 100px;
}

.btn-row {
    display: flex;
    justify-content: center;
    gap: 1rem;
    margin-top: 2rem;
}

.btn-row button {
    padding: 0.55em 1.75em;
    border-radius: 6px;
    border: 1.9px solid #a278e4;
    background-color: transparent;
    color: #a278e4;
    cursor: pointer;
}

.btn-row .fill {
    background-color: transparent;
    color: #C770FE;
    border-radius: 8px;
    border: 1px solid #7644CE !important;
    font-family: 'Poppins', sans-serif;
    font-size: 20px;
}

.btn-row .fill:hover {
    background-color: #7644CE !important;
    color: #fff !important;
    border-radius: 8px !important;
    border: 1px solid #7644CE !important;
    font-family: 'Poppins', sans-serif !important;
    font-size: 20px !important;
}

.hide {
    display: none !important;
}

.show {
    display: block !important;
}

.form-header-row {
    display: flex;
    align-items: center;
    gap: 1rem;
    flex-wrap: wrap;
    margin-bottom: 1.5rem;
}

.form-header-row .form-heading {
    font-size: 24px;
    font-weight: 600;
    color: #fff;
    font-family: 'Poppins', sans-serif;
}

#UN label {
    color: #fff !important;
    font-family: 'Poppins', sans-serif !important;
    font-size: 16px !important;
}

.api-form-wrapper input[type="text"],
.api-form-wrapper select,
.api-form-wrapper textarea {
    background-color: gray !important;
    border: 1px solid gray !important;
    border-radius: 8px !important;
    padding: 10px 14px !important;
    font-size: 16px !important;
    width: 100% !important;
    box-sizing: border-box !important;
    font-family: 'Poppins', sans-serif !important;
    transition: border-color 0.2s ease, box-shadow 0.2s ease !important;
}

.api-form-wrapper input[type="text"]:focus,
.api-form-wrapper select:focus,
.api-form-wrapper textarea:focus {
    border-color: #007BFF !important;
    outline: none !important;
    box-shadow: 0 0 4px rgba(0, 123, 255, 0.4) !important;
}

#UN select {
    background-color: gray !important;
}
</style>

<!-- ✅ HEADING AREA - PRESERVED -->
<div class="merged-ui-wrapper">
    <!-- 🌟 Heading at Top -->
    <div class="api-heading-wrapper">
        <h1 class="api-heading-title">API Revenue Share Lookup</h1>
        <div class="api-heading-bar">
            <span class="border-line"></span>
            <button class="add-api-btn">+ Add API Revenue Share</button>
        </div>
    </div>

    <!-- ✅ CARDS WRAPPER -->
    <div class="api-cards-wrapper" id="UN">
        <div class="api-card-container">
            <div class="api-card-header api-toggle-header">
                <div class="api-price-api-cost">
                    <div class="api-price-section">
                        <div class="label-with-icon">
                            <span class="label">Selling Price (%)</span>
                            <svg class="copy-icon" xmlns="http://www.w3.org/2000/svg" height="14" viewBox="0 0 24 24"
                                width="14" fill="#ccc">
                                <path d="M0 0h24v24H0V0z" fill="none" />
                                <path
                                    d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z" />
                            </svg>
                        </div>
                        <span class="value">8%</span>
                    </div>
                    <div class="api-price-section">
                        <span class="label">API Cost (%)</span>
                        <span class="value">12%</span>
                    </div>
                </div>

                <div class="api-provider-section">
                    <span class="api-info-label">Provider Name</span>
                    <img src="https://wiki.101.games/wp-content/uploads/2025/07/cq9.png" alt="CQ9 Gaming logo"
                        class="api-provider-logo" />
                </div>
            </div>

            <div class="api-details">
                <div class="api-info-grid">
                    <div>
                        <span class="api-info-label">Game Category</span>
                        <span class="api-info-value">Slot</span>
                    </div>
                    <div>
                        <span class="api-info-label">API Type</span>
                        <span class="api-info-value">Single/Crypto Wallet</span>
                    </div>
                    <div>
                        <span class="api-info-label">Game Name</span>
                        <span class="api-info-value">Aviator</span>
                    </div>
                    <div>
                        <span class="api-info-label">Telegram</span>
                        <span class="api-info-value"><a href="#">@CQ9001</a></span>
                    </div>
                    <div>
                        <span class="api-info-label">Official Website</span>
                        <span class="api-info-value"><a href="#">Cq9001.Com</a></span>
                    </div>
                    <div>
                        <span class="api-info-label">Notes</span>
                        <span class="api-info-value">None</span>
                    </div>
                </div>

                <button class="api-report-button">
                    Report
                </button>
            </div>
        </div>
    </div>

    <!-- ✅ FORM WRAPPER -->
    <div class="api-form-wrapper" id="UN">
        <div class="form-header-row">
            <button class="back-button" type="button">
                <svg viewBox="0 0 24 24">
                    <path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z" fill="currentColor"></path>
                </svg>
                Back
            </button>

            <h1 class="form-heading">Add API Revenue Share</h1>
        </div>

        <form>
            <div class="grid-3">
                <div>
                    <label for="selling-price">Selling Price (%)</label>
                    <input id="selling-price" type="text" required />
                </div>
                <div>
                    <label for="api-cost">API Cost (%)</label>
                    <input id="api-cost" type="text" required />
                </div>
                <div>
                    <label for="provider-name">Provider Name</label>
                    <select id="provider-name" required>
                        <option disabled selected>Select</option>
                        <option>Habanero Provider</option>
                        <option>Maya Provider</option>
                        <option>Wazdan Provider</option>
                        <option>PG Soft Provider</option>
                        <option>Spadegaming Provider</option>
                        <option>SpiniX Provider</option>
                        <option>SPRIBE Provider</option>
                        <option>TuDa Gaming Provider</option>
                        <option>BGaming Provider</option>
                        <option>Alize Provider</option>
                        <option>BNG Provider</option>
                        <option>CQ9 Gaming Provider</option>
                    </select>
                </div>
            </div>

            <div class="grid-3">
                <div>
                    <label for="game-category">Game Category</label>
                    <select id="game-category" required>
                        <option>Select</option>
                        <option>Casino Games</option>
                        <option>Sports</option>
                        <option>Local Games</option>
                        <option>P2P Games</option>
                        <option>Casual Games</option>
                    </select>
                </div>
                <div>
                    <label for="api-type">API Type</label>
                    <select id="api-type" required>
                        <option>Select</option>
                        <option>Single/Crypto Wallet</option>
                    </select>
                </div>
                <div>
                    <label for="game-name">Game Name</label>
                    <select id="game-name" required>
                        <option>Select</option>
                        <option>Slot</option>
                        <option>Tables Games</option>
                        <option>Live Casino</option>
                    </select>
                </div>
            </div>

            <div>
                <label for="telegram">Telegram</label>
                <input type="text" id="telegram" required />
            </div>
            <div>
                <label for="website">Website</label>
                <input type="text" id="website" required />
            </div>
            <div>
                <label for="notes">Notes</label>
                <textarea id="notes" required></textarea>
            </div>

            <div class="btn-row">
                <button type="submit" class="fill">confirm</button>
            </div>
        </form>
    </div>
</div>

<!-- <script>
        document.addEventListener("DOMContentLoaded", function () {
            const addBtn = document.querySelector(".add-api-btn");
            const backBtn = document.querySelector(".back-button");
            const cardsWrapper = document.querySelector(".api-cards-wrapper");
            const formWrapper = document.querySelector(".api-form-wrapper");

            // FORM OPEN
            addBtn.addEventListener("click", () => {
                cardsWrapper.classList.add("hide");
                formWrapper.classList.add("show");
            });

            // BACK TO CARDS
            backBtn.addEventListener("click", () => {
                cardsWrapper.classList.remove("hide");
                formWrapper.classList.remove("show");
            });

            // CARD TOGGLE DETAILS
            document.querySelectorAll(".api-toggle-header").forEach((header) => {
                header.addEventListener("click", function () {
                    this.closest(".api-card-container").classList.toggle("open");
                });
            });
        });
    </script> -->

<?php
    return ob_get_clean();
}
add_shortcode('merged_api_ui', 'merged_api_ui_shortcode');