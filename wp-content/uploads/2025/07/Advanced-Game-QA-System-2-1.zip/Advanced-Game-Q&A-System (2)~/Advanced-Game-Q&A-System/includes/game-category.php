<?php // Game Categories shortcode

function game_categories_shortcode($atts) {
    // Define default attributes
    $atts = shortcode_atts(
        array(
            'category' => 'all', // Default tab
        ),
        $atts,
        'game_categories'
    );

    // Define provider data for Casino Games
    $providers = [
        'slot' => [
            ['name' => 'Habanero', 'img' => 'https://wiki.101.games/wp-content/uploads/2025/07/jdb.png', 'alt' => 'Habanero provider logo in stylized orange and red gradient'],
            ['name' => 'Maya', 'img' => 'https://wiki.101.games/wp-content/uploads/2025/07/image-7.png', 'alt' => 'Maya provider logo pink circular emblem with letter M'],
            ['name' => 'Wazdan', 'img' => 'https://wiki.101.games/wp-content/uploads/2025/07/image-7-1.png', 'alt' => 'Wazdan provider logo green stylized letter W on bright round background'],
            ['name' => 'PG Soft', 'img' => 'https://wiki.101.games/wp-content/uploads/2025/07/pg.png', 'alt' => 'PG Soft provider logo composed of pixel style letters P and G'],
        ],
        'table' => [
            ['name' => 'Spadegaming', 'img' => 'https://wiki.101.games/wp-content/uploads/2025/07/gaming.png', 'alt' => 'Spadegaming provider logo in elegant dark red with spade symbol'],
            ['name' => 'SpiniX', 'img' => 'https://wiki.101.games/wp-content/uploads/2025/07/spinix.png', 'alt' => 'SpiniX provider logo in bold white and orange'],
            ['name' => 'SPRIBE', 'img' => 'https://wiki.101.games/wp-content/uploads/2025/07/spribe.png', 'alt' => 'SPRIBE provider logo in white block text'],
            ['name' => 'TuDa Gaming', 'img' => 'https://wiki.101.games/wp-content/uploads/2025/07/tada-1.png', 'alt' => 'TuDa Gaming logo in bright orange'],
        ],
        'live' => [
            ['name' => 'BGaming', 'img' => 'https://wiki.101.games/wp-content/uploads/2025/07/gaming-01.png', 'alt' => 'BGaming logo with yellow capital B and gaming text'],
            ['name' => 'Alize', 'img' => 'https://wiki.101.games/wp-content/uploads/2025/07/alize.png', 'alt' => 'Alize provider blue stylized logo'],
            ['name' => 'BNG', 'img' => 'https://wiki.101.games/wp-content/uploads/2025/07/rng.png', 'alt' => 'BNG provider green circular emblem with abstract B letter'],
            ['name' => 'CQ9 Gaming', 'img' => 'https://wiki.101.games/wp-content/uploads/2025/07/cq9.png', 'alt' => 'CQ9 gaming logo in bright yellow-orange letters'],
            // ['name' => 'Fa Chai', 'img' => 'https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/93c6a9a1-6e19-4d45-aa51-5ca04d8992c8.png', 'alt' => 'Fa Chai provider logo with white and purple accents'],
            // ['name' => 'GTF', 'img' => 'https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/51645c22-47e7-4834-88c3-642c9578b639.png', 'alt' => 'GTF provider logo with blue and green curved icon'],
            // ['name' => 'Habanero', 'img' => 'https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/93354278-35a7-4bb9-b63d-cd1b928fd359.png', 'alt' => 'Repeat Habanero logo, same style as Slot section'],
            // ['name' => 'Hacksaw Gaming', 'img' => 'https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/2f4291f1-5a0b-4a34-8f32-1860db79bb3a.png', 'alt' => 'Hacksaw Gaming provider white text logo'],
        ],
    ];

    // Define tab icons
    $tab_icons = [
    'all'    => '<img src="https://wiki.101.games/wp-content/uploads/2025/07/7777.png" alt="All Icon" class="tab-icon" />',
    'casino' => '<img src="https://wiki.101.games/wp-content/uploads/2025/07/casino.png" alt="Casino Icon" class="tab-icon" />',
    'sports' => '<img src="https://wiki.101.games/wp-content/uploads/2025/07/sp.png" alt="Sports Icon" class="tab-icon" />',
    'local'  => '<img src="https://wiki.101.games/wp-content/uploads/2025/07/lg.png" alt="Local Games Icon" class="tab-icon" />',
    'p2p'    => '<img src="https://wiki.101.games/wp-content/uploads/2025/07/pg3.png" alt="P2P Icon" class="tab-icon" />',
    'casual' => '<img src="https://wiki.101.games/wp-content/uploads/2025/07/cg.png" alt="Casual Games Icon" class="tab-icon" />',
];

    // Start output buffering
ob_start();

// Only render tabs & sections if user is NOT admin or contributor
if ( current_user_can('administrator') || current_user_can('contributor') ) {
?>

<style>
.tab-icon {
    width: clamp(18px, 3vw, 20px);
    height: clamp(18px, 3vw, 20px);
    object-fit: contain;
    margin-right: 0.5rem;
    filter: drop-shadow(0 0 2px rgba(123, 97, 255, 0.6));
    transition: transform 0.2s ease;
}

.tab:hover .tab-icon,
.tab.active .tab-icon {
    filter: brightness(1.2) drop-shadow(0 0 6px rgba(173, 132, 255, 0.5));
    transform: scale(1.05);
}

h2 {
    color: #a566ff;
    font-weight: 600;
    font-size: clamp(1.1rem, 2.5vw, 1.2rem);
}

.tabs {
    display: flex;
    gap: clamp(0.5rem, 1.5vw, 1rem);
    margin-bottom: clamp(1rem, 2vw, 1.5rem);
    flex-wrap: wrap;
    justify-content: flex-start;
}

.tab {
    width: clamp(120px, 25vw, 150px);
    height: clamp(40px, 8vw, 48px);
    background: #2D1A5D;
    border: 1px solid rgba(168, 85, 247, 0.4);
    border-radius: 5px;
    padding: 0 clamp(0.5rem, 1.5vw, 1rem);
    font-size: clamp(10px, 2vw, 11px);
    color: #c9b5ff;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    position: relative;
    text-align: center;
    white-space: nowrap;
    transition: background-color 0.3s ease, color 0.3s ease, box-shadow 0.3s ease;
    font-family: 'Poppins', sans-serif;
}

.tab:hover {
    background: linear-gradient(90deg, #252031 0%, #7644CE 72%);
    border-color: #7644ce;
    box-shadow: 0 0 8px rgba(118, 68, 206, 0.4);
    color: #fff;
}

.tab.active {
    background: linear-gradient(90deg, #7c3aed, #a855f7);
    color: #fff;
    border-color: #c084fc;
    box-shadow: 0 0 12px rgba(168, 85, 247, 0.5);
}

.tab svg,
.tab img {
    width: clamp(18px, 3vw, 22px);
    height: clamp(18px, 3vw, 22px);
    flex-shrink: 0;
}

.section {
    background-color: rgba(35, 20, 75, 0.7);
    border-radius: 1rem;
    box-shadow: 0 0 16px rgba(103, 58, 183, 0.3);
    padding: 1px;
    margin-bottom: clamp(1.5rem, 3vw, 2rem);
    overflow: hidden;
}

.section-header {
    background: linear-gradient(90deg, #7d3dfc, #985eff);
    color: #fff;
    padding: clamp(0.8rem, 2vw, 1rem) clamp(1rem, 2.5vw, 1.25rem);
    font-weight: 600;
    display: flex;
    justify-content: space-between;
    align-items: center;
    cursor: pointer;
    transition: background 0.3s ease;
    user-select: none;
    font-size: clamp(18px, 3.5vw, 22px);
    font-family: 'Poppins', sans-serif;
}

.section-header:hover {
    background: linear-gradient(90deg, #956dfd, #be95ff);
}

.section-header .chevron {
    transition: transform 0.3s ease;
    width: clamp(16px, 2.5vw, 18px);
    height: clamp(16px, 2.5vw, 18px);
    fill: white;
}

.section.open .section-header .chevron {
    transform: rotate(180deg);
}

.section-content {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(clamp(140px, 20vw, 160px), 1fr));
    gap: clamp(0.8rem, 2vw, 1.25rem);
    padding: clamp(1rem, 2.5vw, 1.25rem);
    background-color: transparent;
}

.provider-card {
    background: rgba(30, 18, 58, 0.8);
    border: 1px solid rgba(174, 139, 255, 0.25);
    border-radius: 0.75rem;
    display: flex;
    justify-content: center;
    align-items: center;
    height: clamp(60px, 12vw, 70px);
    padding: clamp(0.8rem, 2vw, 1rem);
    transition: all 0.3s ease;
    box-shadow: 0 0 0 transparent;
    cursor: pointer;
}

.provider-card:hover {
    background-color: rgba(124, 84, 248, 0.15);
    border-color: #a566ff;
    box-shadow: 0 0 10px rgba(168, 102, 255, 0.4);
}

.provider-card img {
    max-height: clamp(45px, 8vw, 55px);
    max-width: 100%;
    object-fit: contain;
    filter: drop-shadow(0 0 2px #7a61ffcc);
    transition: transform 0.2s ease;
}

.provider-card:hover img {
    transform: scale(1.05);
}

.CP {
    font-size: clamp(18px, 3.5vw, 22px);
    font-family: 'Poppins', sans-serif;
}

.section-title {
    grid-column: span 100%;
    font-size: clamp(18px, 3.5vw, 22px);
    font-family: 'Poppins', sans-serif;
    font-weight: 600;
    color: #d6b4ff;
    padding: clamp(15px, 4vw, 30px) 0 clamp(6px, 1.5vw, 8px) clamp(15px, 4vw, 30px);
    user-select: none;
    color: #fff;
}

.section-body {
    overflow: hidden;
    max-height: 0;
    transition: max-height 0.4s ease, padding 0.3s ease;
    padding: 0 clamp(1rem, 2.5vw, 1.5rem);
}

.section.open .section-body {
    max-height: 1000px;
    padding: clamp(1rem, 2.5vw, 1.25rem) clamp(1rem, 2.5vw, 1.5rem) clamp(1.2rem, 3vw, 1.5rem);
}

.custom-chevron {
    transition: transform 0.3s ease;
    transform-origin: center;
    width: clamp(25px, 4vw, 30px);
}

.mt {
    margin-top: clamp(-30px, -5vw, -35px);
}

.fz {
    font-size: clamp(24px, 5vw, 30px);
    color: #c770fe;
}

.heading-divider {
    border: none;
    border-top: 1px solid #666;
    opacity: 0.4;
    margin-bottom: clamp(0.8rem, 2vw, 1rem);
}

.button-bar {
    display: flex;
    justify-content: flex-end;
    margin-bottom: clamp(0.8rem, 2vw, 1.25rem);
}

.add-category-button {
    background-color: #8b5cf6;
    color: white;
    padding: clamp(10px, 2.5vw, 12px) clamp(24px, 5vw, 28px) clamp(10px, 2.5vw, 12px) clamp(15px, 3vw, 18px);
    font-size: clamp(16px, 3vw, 18px);
    border: none;
    border-radius: 86px;
    cursor: pointer;
    transition: background-color 0.3s ease;
    font-family: 'Poppins', sans-serif;
}

.add-category-button:hover {
    background-color: #7c3aed;
}

/* Mobile (≤768px) */
@media screen and (max-width: 768px) {
    .tabs {
        gap: 0.5rem;
        justify-content: center;
    }

    .tab {
        width: clamp(100px, 28vw, 120px);
        height: clamp(36px, 10vw, 40px);
        font-size: clamp(9px, 2.2vw, 10px);
        padding: 0 0.5rem;
    }

    .tab svg,
    .tab img {
        width: clamp(16px, 4vw, 18px);
        height: clamp(16px, 4vw, 18px);
    }

    .section-content {
        grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
        gap: 0.8rem;
        padding: 0.8rem;
    }

    .provider-card {
        height: clamp(50px, 15vw, 60px);
        padding: 0.8rem;
    }

    .provider-card img {
        max-height: clamp(40px, 10vw, 50px);
    }

    .section-title {
        font-size: clamp(16px, 4vw, 18px);
        padding: 15px 0 6px 15px;
    }

    .section-header {
        font-size: clamp(16px, 4vw, 18px);
        padding: 0.8rem 1rem;
    }

    .fz {
        font-size: clamp(20px, 5.5vw, 24px);
    }

    .add-category-button {
        padding: 8px 20px 8px 12px;
        font-size: clamp(14px, 3.5vw, 16px);
    }
}

/* Tablet (769px - 1024px) */
@media screen and (min-width: 769px) and (max-width: 1024px) {
    .tabs {
        gap: 0.8rem;
    }

    .tab {
        width: clamp(130px, 20vw, 140px);
        height: clamp(42px, 7vw, 46px);
        font-size: clamp(10px, 1.8vw, 11px);
    }

    .section-content {
        grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
        gap: 1rem;
    }

    .provider-card {
        height: clamp(60px, 10vw, 65px);
    }

    .provider-card img {
        max-height: clamp(45px, 8vw, 50px);
    }

    .section-title {
        font-size: clamp(18px, 3vw, 20px);
    }

    .section-header {
        font-size: clamp(18px, 3vw, 20px);
    }
}
</style>

<div class="p-6 max-w-7xl mx-auto mt">
    <h1 class="text-2xl font-semibold mb-2 text-purple-400 select-none fz">Game Categories</h1>
    <hr class="heading-divider" />
    <!-- Right-aligned button below line -->
    <div class="button-bar">
        <button class="add-category-button">+ Add New Categories</button>
    </div>


    <div class="tabs" role="tablist" aria-label="Game categories tabs">
        <?php
        $categories = [
            'all'    => 'All',
            'casino' => 'Casino Games',
            'sports' => 'Sports',
            'local'  => 'Local Games',
            'p2p'    => 'P2P Games',
            'casual' => 'Casual Games',
        ];

        foreach ($categories as $key => $label) {
            $active    = ($atts['category'] === $key) ? 'active' : '';
            $selected  = ($atts['category'] === $key) ? 'true' : 'false';
            $tabindex  = ($atts['category'] === $key) ? '0' : '-1';
            echo "<button class='tab $active' role='tab' id='tab-$key' aria-controls='panel-$key' aria-selected='$selected' tabindex='$tabindex'>";
            echo $tab_icons[$key] . $label;
            echo "</button>";
        }
        ?>
    </div>

    <?php foreach ($categories as $key => $label) : ?>
    <section id="panel-<?php echo $key; ?>" role="tabpanel" tabindex="0" aria-labelledby="tab-<?php echo $key; ?>"
        <?php echo ($atts['category'] !== $key) ? 'hidden' : ''; ?>>
        <?php if ($key === 'casino') : ?>
        <?php foreach (['slot' => 'Slot', 'table' => 'Table Games', 'live' => 'Live Casino'] as $sec_key => $sec_label) : ?>
        <div class="section open" id="sec-<?php echo $sec_key; ?>">

            <!-- Accordion header -->
            <div class="section-header" role="button" tabindex="0" aria-expanded="true">
                <?php echo $sec_label; ?>
                <button class="button agqa-status-toggle"
                    style="background: transparent !important; padding: 0; padding-left: 10px;">
                    <img src="https://wiki.101.games/wp-content/uploads/2025/07/arrow-left-s-line.png" alt="Arrow Icon"
                        class="custom-chevron" width="20" height="20" />
                </button>
            </div>

            <!-- ✅ This wrapper includes heading + content -->
            <div class="section-body">
                <!-- <div class="section-title">Common Providers</div> -->
                 <a href="/api-revenue-share-lookup/" class="section-title">Common Providers</a>
                <div class="section-content">
                    <?php foreach ($providers[$sec_key] as $provider) : ?>
                    <div class="provider-card" title="<?php echo $provider['name']; ?> Provider">
                        <img src="<?php echo $provider['img']; ?>" alt="<?php echo $provider['alt']; ?>"
                            onerror="this.style.filter='grayscale(1)'; this.style.opacity='0.6';" />
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

        </div>
        <?php endforeach; ?>
        <?php else : ?>
        <p class="text-center text-gray-400 py-6 select-none"><?php echo $label; ?> content placeholder</p>
        <?php endif; ?>
    </section>
    <?php endforeach; ?>
</div>

<script>
const tabs = document.querySelectorAll(".tab");
const panels = document.querySelectorAll("[role='tabpanel']");

// ✅ Tab Switching Logic
tabs.forEach(tab => {
    tab.addEventListener('click', () => {
        // Remove active from all tabs
        tabs.forEach(t => {
            t.classList.remove('active');
            t.setAttribute("aria-selected", "false");
            t.setAttribute("tabindex", "-1");
        });

        // Hide all panels
        panels.forEach(p => p.hidden = true);

        // Activate selected tab
        tab.classList.add('active');
        tab.setAttribute("aria-selected", "true");
        tab.setAttribute("tabindex", "0");

        // Show corresponding panel
        const panelId = tab.getAttribute("aria-controls");
        const panel = document.getElementById(panelId);
        panel.hidden = false;
        panel.focus();
    });

    // Keyboard navigation
    tab.addEventListener('keydown', e => {
        let index = Array.prototype.indexOf.call(tabs, e.currentTarget);
        if (e.key === "ArrowRight") {
            e.preventDefault();
            let next = tabs[(index + 1) % tabs.length];
            next.focus();
        } else if (e.key === "ArrowLeft") {
            e.preventDefault();
            let prev = tabs[(index - 1 + tabs.length) % tabs.length];
            prev.focus();
        }
    });
});


// ✅ Accordion Toggle + <img> Arrow Rotation Logic
document.querySelectorAll('.section-header').forEach(header => {
    header.addEventListener('click', () => {
        const section = header.parentElement;
        const body = section.querySelector('.section-body'); // Contains title + content
        const toggleBtn = header.querySelector('.agqa-status-toggle');
        const arrowImg = toggleBtn ? toggleBtn.querySelector('.custom-chevron') : null;

        const isOpen = section.classList.contains('open');

        if (isOpen) {
            section.classList.remove('open');
            header.setAttribute('aria-expanded', 'false');
            if (body) body.style.display = 'none';

            // Rotate arrow image back
            if (arrowImg) arrowImg.style.transform = 'rotate(0deg)';
        } else {
            section.classList.add('open');
            header.setAttribute('aria-expanded', 'true');
            if (body) body.style.display = 'block';

            // Rotate arrow image
            if (arrowImg) arrowImg.style.transform = 'rotate(180deg)';
        }
    });

    // Keyboard toggle
    header.addEventListener('keydown', e => {
        if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            header.click();
        }
    });
});
</script>
<?php
    return ob_get_clean();
} }

// Register the shortcode
add_shortcode('game_categories', 'game_categories_shortcode');
?>