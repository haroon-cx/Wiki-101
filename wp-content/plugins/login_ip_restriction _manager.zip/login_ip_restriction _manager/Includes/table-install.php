<?php
// Main plugin file: register activation hook

function agqa_create_tables_ip_users()
{
    global $wpdb;
    $charsets = $wpdb->get_charset_collate();

    // Create the agqa_wiki_add_users table

    $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}agqa_wiki_add_users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id VARCHAR(255) NOT NULL,
            account VARCHAR(255) NOT NULL,
            new_password VARCHAR(255) NOT NULL,
            confirm_password VARCHAR(255) NOT NULL,
            state VARCHAR(255) NOT NULL,
            user_role VARCHAR(255) NOT NULL,
            company_name VARCHAR(255) NOT NULL,
            email VARCHAR(255) NOT NULL,
            delete_status VARCHAR(255) NOT NULL,
            delete_user_name VARCHAR(255) NOT NULL,
            delete_user_id VARCHAR(255) NOT NULL,
            custom_label_1 VARCHAR(255),
            custom_label_2 VARCHAR(255),
            custom_label_3 VARCHAR(255),
            custom_label_4 VARCHAR(255),
            custom_field_1 VARCHAR(255),
            custom_field_2 VARCHAR(255),
            custom_field_3 VARCHAR(255),
            custom_field_4 VARCHAR(255),
            created_at DATE NOT NULL DEFAULT (CURRENT_DATE)
        ) $charsets;");

    $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}agqa_wiki_add_ip (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id VARCHAR(255) NOT NULL,
        account VARCHAR(255) NOT NULL,
        ipv4 VARCHAR(255) NOT NULL,
        ipv6 VARCHAR(255) NOT NULL,
        delete_status VARCHAR(255) NOT NULL,
        delete_user_name VARCHAR(255) NOT NULL,
        delete_user_id VARCHAR(255) NOT NULL,
        created_at DATE NOT NULL DEFAULT (CURRENT_DATE)
    ) $charsets;");

    $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}agqa_wiki_login_records (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id VARCHAR(255) NOT NULL,
        account VARCHAR(255) NOT NULL,
        login_ip VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) $charsets;");

    $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}agqa_wiki_read_user_profile (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id VARCHAR(255) NOT NULL,
        read_user_profile VARCHAR(255) NOT NULL
    ) $charsets;");

    //  $table = $wpdb->prefix . 'agqa_wiki_login_records'; // => wp_agqa_wiki_login_records
    // $wpdb->query("DROP TABLE IF EXISTS `$table`");
}
