<?php
function custom_faq_shortcode($atts) {
    // Optional: Define attributes with defaults
    $atts = shortcode_atts(array(
        'category' => '', // Optionally pass a category slug
    ), $atts);

    ob_start(); // Start output buffering

    // 👉 Example custom PHP logic
    // You can replace this with your own data source or logic
    $faqs = array(
        array(
            'question' => 'What is your return policy?',
            'answer'   => 'You can return any item within 30 days of purchase.'
        ),
        array(
            'question' => 'Do you offer international shipping?',
            'answer'   => 'Yes, we ship to most countries worldwide.'
        ),
        array(
            'question' => 'How do I contact support?',
            'answer'   => 'You can contact us via the support form or by calling 123-456-7890.'
        ),
    );

    // Output the FAQ in HTML
    echo '<div class="custom-faq">';
    foreach ($faqs as $faq) {
        echo '<div class="faq-item">';
        echo '<h3 class="faq-question">' . esc_html($faq['question']) . '</h3>';
        echo '<div class="faq-answer">' . esc_html($faq['answer']) . '</div>';
        echo '</div>';
    }
    echo '</div>';

    return ob_get_clean(); // Return the buffered content
}
add_shortcode('custom_faq', 'custom_faq_shortcode');


?>