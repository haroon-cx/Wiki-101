<?php 

function merged_api_ui_shortcode() {
    ob_start();
    ?>

<style>
/* 🌈 ========== GLOBAL & WRAPPERS ========== */
.api-form-wrapper {
    display: none;
}

.api-form-wrapper h1 {
    margin-top: -9px;
    font-size: 32px;
    color: #c770fe;
}

.api-form-wrapper.show {
    display: block;
}

.api-cards-wrapper.hide {
    display: none;
}

.api-cards-wrapper {
    color: #fff;
}

/* ✅ ORIGINAL HEADING DESIGN PRESERVED */
.api-heading-wrapper {
    max-width: 1340px;
    font-family: 'Poppins', sans-serif;
}

.api-heading-title {
    font-size: 32px;
    color: #c770fe;
    margin-bottom: 20px;
    border-bottom: 1px solid gray;
    font-family: 'Poppins', sans-serif;
    margin-top: 1px;

}

.api-heading-bar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-bottom: 8px;
}

.border-line {
    flex: 1;
}

.add-api-btn {
    background-color: #7e3af2;
    color: white;
    border: none;
    padding: 10px 22px;
    border-radius: 25px;
    font-weight: 500;
    font-size: 14px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.add-api-btn.hide {
    display: none !important;
}

.add-api-btn:hover {
    background-color: #6528e0;
}

/* ✅ CARD STYLES */

/* === FINAL CARD FIX === */
.api-card-container {
    background: linear-gradient(0deg, rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.2)), linear-gradient(91.48deg, #252031 31.31%, #7644CE 135.46%);
    border-radius: 16px;
    padding: 36px 54px 24px;
    max-width: 1290px;
    margin-top: 20px;
    transition: all .3s ease-in-out;
    font-family: 'Poppins', sans-serif;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
}

.api-card-container:hover {
    background: linear-gradient(0deg, rgba(0, 0, 0, 0.1), rgba(0, 0, 0, 0.1)), linear-gradient(91.48deg, #252031 31.31%, #7644CE 120.46%);
}

.api-card-header {
    display: flex;
    flex-wrap: wrap;
    gap: 2% 5%;
    cursor: pointer;
}

.api-provider-section,
.api-revenue-states{
    margin-top: 13px;
}

.api-price-api-cost {
    background: linear-gradient(276.11deg, rgba(98, 68, 145, 0.2) 52.19%, rgba(238, 54, 255, 0.2) 129.2%);
    border-radius: 8px;
    padding: 13px 45px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    color: #fff;
    width: 30.46%;  
}

.label-with-icon {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 16px;
}


.label-with-icon svg,
.api-price-section h2{
    margin-bottom: 0;
}

.label-with-icon svg{
    width:17px;
}

.copy-icon {
    cursor: pointer;
    margin: -12px 0 0 3px;
    transition: opacity 0.3s ease;
}

.copy-icon:hover {
    opacity: 0.6;
}

.api-price-section .label {
    display: block;
}

.api-provider-section {
    width:25%;
}

.api-provider-section-inner {
    display: flex;
    flex-direction: column;
    justify-content: center;
    width: max-content;
    text-align: center;
    gap: 4px;
}

.api-info-img{
    line-height: .6;
    width:104px;
    height: 68px;
    display: flex;
    justify-content: center;
    align-items: center;
}

.api-info-img img{
max-width: 104px;
max-height: 104px;
}

.api-info-img + span {
    font-weight: 600;
}

/* === DETAILS BELOW === */
/* === DETAILS Toggle === */
.api-details {
    display: none;
}

.api-info-grid-list{
    display: flex;
    gap: 24px 30px;
}

.api-info-grid-list:nth-child(n + 2){
    margin-top: 38px;
}

.api-info-grid-item:nth-of-type(1){
    margin-right: 7.5%;
}

.api-info-grid-item:nth-of-type(1){
    width: 32%;
}

.api-info-grid-item:nth-of-type(2) {
    width: 30%;
}

.api-info-grid-item:nth-of-type(3){
    width: 20%;
}

.api-info-value a {
    color: #00b6ff;
    text-decoration: none;
}


.api-report-icon {
    width: 14px;
    height: 14px;
}

.api-card-button{
    background-color: rgba(234, 221, 255, .16);
    border-radius: 42px;
    padding: 6px 12px;
    font-size: 16px;
    color: #fff;
    cursor: pointer;
    display: flex;
    gap: 7px;
}

.api-card-bottom-buttons{
    display: flex;
    gap: 16px;
}

.back-button {
    display: inline-flex;
    align-items: center;
    font-size: 20px;
    color: #fff;
    border: 1.5px solid #a278e4;
    border-radius: 999px;
    padding: 6px 14px;
    cursor: pointer;
    margin-bottom: 1.8rem;
    background-color: transparent;
    font-family: 'Poppins', sans-serif;
}

.back-button svg {
    width: 30px;
    height: 30px;
}

.grid-3 {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
    gap: 1rem 1.5rem;
    margin-bottom: 1.5rem;
}

input[type="text"],
select,
textarea {
    width: 100%;
    padding: 0.65em 1em;
    border-radius: 6px;
    border: none;
    font-size: 0.95rem;
    background: #7a7a7a;
    color: #ddd;
}

textarea {
    min-height: 100px;
}

.btn-row {
    display: flex;
    justify-content: center;
    gap: 1rem;
    margin-top: 2rem;
}

.btn-row button {
    padding: 0.55em 1.75em;
    border-radius: 6px;
    border: 1.9px solid #a278e4;
    background-color: transparent;
    color: #a278e4;
    cursor: pointer;
}

.btn-row .fill {
    background-color: transparent;
    color: #C770FE;
    border-radius: 8px;
    border: 1px solid #7644CE !important;
    font-family: 'Poppins', sans-serif;
    font-size: 20px;
}

.btn-row .fill:hover {
    background-color: #7644CE !important;
    color: #fff !important;
    border-radius: 8px !important;
    border: 1px solid #7644CE !important;
    font-family: 'Poppins', sans-serif !important;
    font-size: 20px !important;
}

.hide {
    display: none !important;
}

.show {
    display: block !important;
}

.form-header-row {
    display: flex;
    align-items: center;
    gap: 1rem;
    flex-wrap: wrap;
    margin-bottom: 1.5rem;
}

.form-header-row .form-heading {
    font-size: 24px;
    font-weight: 600;
    color: #fff;
    font-family: 'Poppins', sans-serif;
}

#UN label {
    color: #fff !important;
    font-family: 'Poppins', sans-serif !important;
    font-size: 16px !important;
}

.api-form-wrapper input[type="text"],
.api-form-wrapper select,
.api-form-wrapper textarea {
    background-color: gray !important;
    border: 1px solid gray !important;
    border-radius: 8px !important;
    padding: 10px 14px !important;
    font-size: 16px !important;
    width: 100% !important;
    box-sizing: border-box !important;
    font-family: 'Poppins', sans-serif !important;
    transition: border-color 0.2s ease, box-shadow 0.2s ease !important;
}

.api-form-wrapper input[type="text"]:focus,
.api-form-wrapper select:focus,
.api-form-wrapper textarea:focus {
    border-color: #007BFF !important;
    outline: none !important;
    box-shadow: 0 0 4px rgba(0, 123, 255, 0.4) !important;
}

#UN select {
    background-color: gray !important;
}
.fz {
    font-size: clamp(24px, 5vw, 30px);
    color: #c770fe;
    margin-top: 1px;
}

.add-category-button:hover {
    background-color: #7c3aed;
}

.api-info-grid {
    width: 90%;
    margin-inline: auto;
    margin-top: 36px;
}

.api-info-label {
    margin-bottom: 7px;
}

.api-card-bottom{
    margin-top: 19px;
}
.api-filter .filter-area{ 
    min-width: max-content;
}

.api-filter-buttons{
    display: flex;
    gap: 16px;
}

</style>

<!-- ✅ HEADING AREA - PRESERVED -->
<div class="merged-ui-wrapper">
    <!-- 🌟 Heading at Top -->
   <div class="api-heading-wrapper">
        <h1 class="text-2xl font-semibold mb-2 text-purple-400 select-none fz">Revenue</h1>
        <hr class="heading-divider" />
        <div class="filter-container api-filter">
        <div class="filter-area">
                    <form action="#">
                        <div class="filter-select">
                            <input type="hidden" name="filter-select-hidden" class="agqa-filter-select-hidden">
                            <button class="filter-select-title">
                                <span class="filter-default-text">selcet Role</span>
                                <span class="filter-selected-text"></span>
                            </button>
                            <div class="filter-select-list">
                                <ul>
                                    <li>Disabled</li>
                                    <li>Enabled</li>
                                </ul>
                            </div>
                        </div>
                        <button type="submit" class="filter-select-button"><span>Search</span></button>
                    </form>
                </div>
                <div class="api-filter-buttons">
                    <button class="add-category-button gradient-btn"><img decoding="async" src="http://wiki101.local/wp-content/plugins/Advanced-Game-Q&amp;A-System/assets/images/reorder-icon.svg" alt="Reorder Icon">
                            Reorder</button>
                    <button class="add-category-button gradient-btn"><img decoding="async" src="http://wiki101.local/wp-content/plugins/Advanced-Game-Q&amp;A-System/assets/images/plus-icon.svg" alt="Plus Icon">
                            Add Api</button>
                </div>
                </div>
    </div>

    <!-- ✅ CARDS WRAPPER -->
    <div class="api-cards-wrapper" id="UN">
        <div class="api-card-container">
            <div class="api-card-header api-toggle-header">
                <div class="api-price-api-cost">
                    <div class="api-price-section">
                        <div class="label-with-icon">
                            <span class="label">Selling Price (%)</span>
                            <img src="<?php echo AGQA_URL ?>assets/images/copy-icon.svg" alt="Copy Icon">
                        </div>
                        <h2 class="large-text">16%</h2>
                    </div>
                    <div class="api-price-section">
                        <span class="label">API Cost (%)</span>
                        <h2 class="large-text">8%</h2>
                    </div>
                </div>
                <div class="api-provider-section">
                <div class="api-provider-section-inner">
                    <span class="api-info-label">Provider Name</span>
                    <div class="api-info-img">
                        <img src="<?php echo AGQA_URL ?>assets/images/cq9.png" alt="">
                        <!-- <img src="https://wiki.101.games/wp-content/uploads/2025/07/cq9.png" alt="CQ9 Gaming logo">
                        class="api-provider-logo" /> -->
                        </div>
                        <span>CQ9</span>
                </div>
                </div>
                <div class="api-revenue-states">
                    <div class="api-revenue-states-label">
                        <span>State</span>
                    </div>
                    <div class="api-revenue-states-buttons">
                        <span class="disabled">Disabled</span>    
                    </div>
                </div>  
            </div>
            <div class="api-details">
                <div class="api-info-grid">
                    <div class="api-info-grid-list">
                        <div class="api-info-grid-item">
                            <span class="api-info-label">Game Category</span>
                            <h2 class="api-info-value">Casino Games</h2>
                        </div>
                        <div class="api-info-grid-item">
                            <span class="api-info-label">Game Type</span>
                            <h2 class="api-info-value">Slot</h2>
                        </div>
                        <div class="api-info-grid-item">
                            <span class="api-info-label">Game Info Website</span>
                            <h2 class="api-info-value"><a href="cq9001.com">cq9001.com</a></h2>
                         </div>
                    </div>
                    <div class="api-info-grid-list">
                        <div class="api-info-grid-item">
                            <span class="api-info-label">Game Demo Website</span>
                            <h2 class="api-info-value"><a href="cq9001demo.com">cq9001demo.com</a></h2>
                        </div>
                        <div class="api-info-grid-item">
                            <span class="api-info-label">API Type</span>
                            <h2 class="api-info-value">Single/Crypto Wallet</h2>
                        </div>
                        <div class="api-info-grid-item">
                            <span class="api-info-label">Representative’s Name</span>
                            <h2 class="api-info-value"><a href="cq9001.com">Edison Chen</a></h2>
                    </div>
                    </div>
                    <div class="api-info-grid-list">
                        <div class="api-info-grid-item">
                            <span class="api-info-label">Telegram</span>
                            <h2 class="api-info-value"><a href="@cQ9001">@cQ9001</a></h2>
                        </div>
                        <div class="api-info-grid-item">
                            <span class="api-info-label">Contra Ct</span>
                            <h2 class="api-info-value"><a href="#">View details</a></h2>
                        </div>  
                    </div>  
                    <div class="api-info-grid-list">
                        <div class="api-info-grid-item">
                            <span class="api-info-label">Notes</span>
                            <h2 class="api-info-value">None</h2>
                        </div>  
                    </div>
                </div>
            <div class="api-card-bottom">
                <div class="api-card-bottom-buttons">
                    <button class="api-report-button api-card-button">
                       <img src="<?php echo AGQA_URL ?>assets/images/edit-icon.svg" alt="Edit Icon"> Edit
                    </button>
                    <button class="api-edit-button api-card-button">
                        <img src="<?php echo AGQA_URL ?>assets/images/alert-icon.svg" alt="Alert Icon"> Report
                    </button>
                </div>
                <!-- <div class="api-card-user-dropdown dropdown-ctn">
                    <div class="dropdown-title">
                        heather01 
                    </div>
                    <div class="dropdown-lists">
                         <div class="api-card-user-items">
                             <div class="api-card-user-item">
                                       
                             </div>
                             <div class="api-card-user-head-title">
                                Change Time
                             </div>
                             <div class="api-card-user-head-title">
                                Change Time
                             </div>
                         </div>
                    </div>
                </div> -->
            </div>
            </div>

    <!-- ✅ FORM WRAPPER -->
    <!-- <div class="api-form-wrapper" id="UN">
        <div class="form-header-row">
            <button class="back-button" type="button">
                <svg viewBox="0 0 24 24">
                    <path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z" fill="currentColor"></path>
                </svg>
                Back
            </button>

            <h1 class="form-heading">Add API Revenue Share</h1>
        </div>

        <form>
            <div class="grid-3">
                <div>
                    <label for="selling-price">Selling Price (%)</label>
                    <input id="selling-price" type="text" required />
                </div>
                <div>
                    <label for="api-cost">API Cost (%)</label>
                    <input id="api-cost" type="text" required />
                </div>
                <div>
                    <label for="provider-name">Provider Name</label>
                    <select id="provider-name" required>
                        <option disabled selected>Select</option>
                        <option>Habanero Provider</option>
                        <option>Maya Provider</option>
                        <option>Wazdan Provider</option>
                        <option>PG Soft Provider</option>
                        <option>Spadegaming Provider</option>
                        <option>SpiniX Provider</option>
                        <option>SPRIBE Provider</option>
                        <option>TuDa Gaming Provider</option>
                        <option>BGaming Provider</option>
                        <option>Alize Provider</option>
                        <option>BNG Provider</option>
                        <option>CQ9 Gaming Provider</option>
                    </select>
                </div>
            </div>

            <div class="grid-3">
                <div>
                    <label for="game-category">Game Category</label>
                    <select id="game-category" required>
                        <option>Select</option>
                        <option>Casino Games</option>
                        <option>Sports</option>
                        <option>Local Games</option>
                        <option>P2P Games</option>
                        <option>Casual Games</option>
                    </select>
                </div>
                <div>
                    <label for="api-type">API Type</label>
                    <select id="api-type" required>
                        <option>Select</option>
                        <option>Single/Crypto Wallet</option>
                    </select>
                </div>
                <div>
                    <label for="game-name">Game Name</label>
                    <select id="game-name" required>
                        <option>Select</option>
                        <option>Slot</option>
                        <option>Tables Games</option>
                        <option>Live Casino</option>
                    </select>
                </div>
            </div>

            <div>
                <label for="telegram">Telegram</label>
                <input type="text" id="telegram" required />
            </div>
            <div>
                <label for="website">Website</label>
                <input type="text" id="website" required />
            </div>
            <div>
                <label for="notes">Notes</label>
                <textarea id="notes" required></textarea>
            </div>

            <div class="btn-row">
                <button type="submit" class="fill">confirm</button>
            </div>
        </form>
    </div> -->
        </div>
         <div class="api-card-container">
            <div class="api-card-header api-toggle-header">
                <div class="api-price-api-cost">
                    <div class="api-price-section">
                        <div class="label-with-icon">
                            <span class="label">Selling Price (%)</span>
                            <img src="<?php echo AGQA_URL ?>assets/images/copy-icon.svg" alt="Copy Icon">
                        </div>
                        <h2 class="large-text">16%</h2>
                    </div>
                    <div class="api-price-section">
                        <span class="label">API Cost (%)</span>
                        <h2 class="large-text">8%</h2>
                    </div>
                </div>
                <div class="api-provider-section">
                <div class="api-provider-section-inner">
                    <span class="api-info-label">Provider Name</span>
                    <div class="api-info-img">
                        <img src="<?php echo AGQA_URL ?>assets/images/microgaming.png" alt="">
                        <!-- <img src="https://wiki.101.games/wp-content/uploads/2025/07/cq9.png" alt="CQ9 Gaming logo">
                        class="api-provider-logo" /> -->
                        </div>
                        <span>CQ9</span>
                </div>
                </div>
                <div class="api-revenue-states">
                    <div class="api-revenue-states-label">
                        <span>State</span>
                    </div>
                    <div class="api-revenue-states-buttons">
                        <span class="enabled">Enabled</span>    
                    </div>
                </div>  
            </div>
            <div class="api-details">
                <div class="api-info-grid">
                    <div class="api-info-grid-list">
                        <div class="api-info-grid-item">
                            <span class="api-info-label">Game Category</span>
                            <h2 class="api-info-value">Casino Games</h2>
                        </div>
                        <div class="api-info-grid-item">
                            <span class="api-info-label">Game Type</span>
                            <h2 class="api-info-value">Slot</h2>
                        </div>
                        <div class="api-info-grid-item">
                            <span class="api-info-label">Game Info Website</span>
                            <h2 class="api-info-value"><a href="cq9001.com">cq9001.com</a></h2>
                         </div>
                    </div>
                    <div class="api-info-grid-list">
                        <div class="api-info-grid-item">
                            <span class="api-info-label">Game Demo Website</span>
                            <h2 class="api-info-value"><a href="cq9001demo.com">cq9001demo.com</a></h2>
                        </div>
                        <div class="api-info-grid-item">
                            <span class="api-info-label">API Type</span>
                            <h2 class="api-info-value">Single/Crypto Wallet</h2>
                        </div>
                        <div class="api-info-grid-item">
                            <span class="api-info-label">Representative’s Name</span>
                            <h2 class="api-info-value"><a href="cq9001.com">Edison Chen</a></h2>
                    </div>
                    </div>
                    <div class="api-info-grid-list">
                        <div class="api-info-grid-item">
                            <span class="api-info-label">Telegram</span>
                            <h2 class="api-info-value"><a href="@cQ9001">@cQ9001</a></h2>
                        </div>
                        <div class="api-info-grid-item">
                            <span class="api-info-label">Contract</span>
                            <h2 class="api-info-value"><a href="#">CQ9_Contract_20230612.pdf</a></h2>
                            <div id="pdf-popup" class="pdf-popup">
                            <div class="pdf-popup-head">
                                <h2>Slot</h2> 
                                <div class="cross-icon"><img src="<?php echo AGQA_URL ?>assets/images/close-icon.svg" alt="Close Icon"></div>
                            </div>
                            <div class="pdf-popup-body">
                                 <div class="pdf-document">
                                    <img src="<?php echo AGQA_URL ?>assets/images/Fake_Partnership_Agreement 1.png" alt="Copy Icon">
                                 </div>
                            </div>
                            </div>
                        </div>  
                    </div>  
                    <div class="api-info-grid-list">
                        <div class="api-info-grid-item">
                            <span class="api-info-label">Notes</span>
                            <h2 class="api-info-value">None</h2>
                        </div>  
                    </div>
                </div>
            <div class="api-card-bottom">
                <div class="api-card-bottom-buttons">
                    <button class="api-report-button api-card-button">
                       <img src="<?php echo AGQA_URL ?>assets/images/edit-icon.svg" alt="Edit Icon"> Edit
                    </button>
                    <button class="api-edit-button api-card-button">
                        <img src="<?php echo AGQA_URL ?>assets/images/alert-icon.svg" alt="Alert Icon"> Report
                    </button>
                </div>
                <!-- <div class="api-card-user-dropdown dropdown-ctn">
                    <div class="dropdown-title">
                        heather01 
                    </div>
                    <div class="dropdown-lists">
                         <div class="api-card-user-items">
                             <div class="api-card-user-item">
                                       
                             </div>
                             <div class="api-card-user-head-title">
                                Change Time
                             </div>
                             <div class="api-card-user-head-title">
                                Change Time
                             </div>
                         </div>
                    </div>
                </div> -->
            </div>
            </div>

    <!-- ✅ FORM WRAPPER -->
    <!-- <div class="api-form-wrapper" id="UN">
        <div class="form-header-row">
            <button class="back-button" type="button">
                <svg viewBox="0 0 24 24">
                    <path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z" fill="currentColor"></path>
                </svg>
                Back
            </button>

            <h1 class="form-heading">Add API Revenue Share</h1>
        </div>

        <form>
            <div class="grid-3">
                <div>
                    <label for="selling-price">Selling Price (%)</label>
                    <input id="selling-price" type="text" required />
                </div>
                <div>
                    <label for="api-cost">API Cost (%)</label>
                    <input id="api-cost" type="text" required />
                </div>
                <div>
                    <label for="provider-name">Provider Name</label>
                    <select id="provider-name" required>
                        <option disabled selected>Select</option>
                        <option>Habanero Provider</option>
                        <option>Maya Provider</option>
                        <option>Wazdan Provider</option>
                        <option>PG Soft Provider</option>
                        <option>Spadegaming Provider</option>
                        <option>SpiniX Provider</option>
                        <option>SPRIBE Provider</option>
                        <option>TuDa Gaming Provider</option>
                        <option>BGaming Provider</option>
                        <option>Alize Provider</option>
                        <option>BNG Provider</option>
                        <option>CQ9 Gaming Provider</option>
                    </select>
                </div>
            </div>

            <div class="grid-3">
                <div>
                    <label for="game-category">Game Category</label>
                    <select id="game-category" required>
                        <option>Select</option>
                        <option>Casino Games</option>
                        <option>Sports</option>
                        <option>Local Games</option>
                        <option>P2P Games</option>
                        <option>Casual Games</option>
                    </select>
                </div>
                <div>
                    <label for="api-type">API Type</label>
                    <select id="api-type" required>
                        <option>Select</option>
                        <option>Single/Crypto Wallet</option>
                    </select>
                </div>
                <div>
                    <label for="game-name">Game Name</label>
                    <select id="game-name" required>
                        <option>Select</option>
                        <option>Slot</option>
                        <option>Tables Games</option>
                        <option>Live Casino</option>
                    </select>
                </div>
            </div>

            <div>
                <label for="telegram">Telegram</label>
                <input type="text" id="telegram" required />
            </div>
            <div>
                <label for="website">Website</label>
                <input type="text" id="website" required />
            </div>
            <div>
                <label for="notes">Notes</label>
                <textarea id="notes" required></textarea>
            </div>

            <div class="btn-row">
                <button type="submit" class="fill">confirm</button>
            </div>
        </form>
    </div> -->
        </div>

<!-- <script>
        document.addEventListener("DOMContentLoaded", function () {
            const addBtn = document.querySelector(".add-api-btn");
            const backBtn = document.querySelector(".back-button");
            const cardsWrapper = document.querySelector(".api-cards-wrapper");
            const formWrapper = document.querySelector(".api-form-wrapper");

            // FORM OPEN
            addBtn.addEventListener("click", () => {
                cardsWrapper.classList.add("hide");
                formWrapper.classList.add("show");
            });

            // BACK TO CARDS
            backBtn.addEventListener("click", () => {
                cardsWrapper.classList.remove("hide");
                formWrapper.classList.remove("show");
            });

            // CARD TOGGLE DETAILS
            document.querySelectorAll(".api-toggle-header").forEach((header) => {
                header.addEventListener("click", function () {
                    this.closest(".api-card-container").classList.toggle("open");
                });
            });
        });
    </script> -->

<?php
    return ob_get_clean();
}
add_shortcode('merged_api_ui', 'merged_api_ui_shortcode');