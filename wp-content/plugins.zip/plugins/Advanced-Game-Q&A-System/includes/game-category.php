<?php
// Game Categories shortcode
function game_categories_shortcode($atts)
{
    // Define default attributes
    $atts = shortcode_atts(
        array(
            'category' => 'all', // Default tab
        ),
        $atts,
        'game_categories'
    );

    // Base path for images (dynamically generated)
    $upload_dir = wp_upload_dir();
    $image_base_url = trailingslashit($upload_dir['baseurl']) . '2025/07/';
    $image_base_path = trailingslashit($upload_dir['basedir']) . '2025/07/'; // For file_exists()

    // Determine arrow image extension
    $arrow_image_name = 'arrow-left-s-line';
    $arrow_image_ext = file_exists($image_base_path . $arrow_image_name . '.svg') ? '.svg' : '.png';
    $arrow_image_url = esc_url($image_base_url . $arrow_image_name . $arrow_image_ext);

    // Define provider data for all categories
    $providers = [
        'slot' => [
            ['name' => 'Habanero', 'img' => 'jdb.png', 'alt' => 'Habanero provider logo in stylized orange and red gradient'],
            ['name' => 'Maya', 'img' => 'image-7.png', 'alt' => 'Maya provider logo pink circular emblem with letter M'],
            ['name' => 'Wazdan', 'img' => 'image-7-1.png', 'alt' => 'Wazdan provider logo green stylized letter W on bright round background'],
            ['name' => 'PG Soft', 'img' => 'pg.png', 'alt' => 'PG Soft provider logo composed of pixel style letters P and G'],
        ],
        'table' => [
            ['name' => 'Spadegaming', 'img' => 'gaming.png', 'alt' => 'Spadegaming provider logo in elegant dark red with spade symbol'],
            ['name' => 'SpiniX', 'img' => 'spinix.png', 'alt' => 'SpiniX provider logo in bold white and orange'],
            ['name' => 'SPRIBE', 'img' => 'spribe.png', 'alt' => 'SPRIBE provider logo in white block text'],
            ['name' => 'TuDa Gaming', 'img' => 'tada-1.png', 'alt' => 'TuDa Gaming logo in bright orange'],
        ],
        'live' => [
            ['name' => 'BGaming', 'img' => 'gaming-01.png', 'alt' => 'BGaming logo with yellow capital B and gaming text'],
            ['name' => 'Alize', 'img' => 'alize.png', 'alt' => 'Alize provider blue stylized logo'],
            ['name' => 'BNG', 'img' => 'rng.png', 'alt' => 'BNG provider green circular emblem with abstract B letter'],
            ['name' => 'CQ9 Gaming', 'img' => 'cq9.png', 'alt' => 'CQ9 gaming logo in bright yellow-orange letters'],
        ],
        'sports' => [
            ['name' => 'SABA Sports', 'img' => 'jdb.png', 'alt' => 'SABA Sports logo in blue and white'],
            ['name' => 'Bet365', 'img' => 'cq9.png', 'alt' => 'Bet365 logo in green and yellow'],
            ['name' => 'Pinnacle', 'img' => 'rng.png', 'alt' => 'Pinnacle logo in black and orange'],
        ],
        'local' => [
            ['name' => 'Rummy', 'img' => 'tada-1.png', 'alt' => 'Rummy provider logo in traditional red and black'],
            ['name' => 'Teen Patti', 'img' => 'jdb.png', 'alt' => 'Teen Patti logo with card motifs'],
        ],
        'p2p' => [
            ['name' => 'PeerBet', 'img' => 'rng.png', 'alt' => 'PeerBet logo in modern blue gradient'],
            ['name' => 'P2P Gaming', 'img' => 'jdb.png', 'alt' => 'P2P Gaming logo with peer-to-peer icon'],
        ],
        'casual' => [
            ['name' => 'KingMaker', 'img' => 'gaming.png', 'alt' => 'KingMaker logo in vibrant purple'],
            ['name' => 'SimplePlay', 'img' => 'gaming-01.png', 'alt' => 'SimplePlay logo in playful green'],
        ],
    ];

    // Define tab icons
    $tab_icons = [
        'all'    => '<img src="' . esc_url($image_base_url . '7777.png') . '" alt="All Icon" class="tab-icon" />',
        'casino' => '<img src="' . esc_url($image_base_url . 'casino.png') . '" alt="Casino Icon" class="tab-icon" />',
        'sports' => '<img src="' . esc_url($image_base_url . 'sp.png') . '" alt="Sports Icon" class="tab-icon" />',
        'local'  => '<img src="' . esc_url($image_base_url . 'lg.png') . '" alt="Local Games Icon" class="tab-icon" />',
        'p2p'    => '<img src="' . esc_url($image_base_url . 'pg3.png') . '" alt="P2P Icon" class="tab-icon" />',
        'casual' => '<img src="' . esc_url($image_base_url . 'cg.png') . '" alt="Casual Games Icon" class="tab-icon" />',
    ];

    // Define category sections
    $category_sections = [
        'casino' => ['slot' => 'Slot', 'table' => 'Table Games', 'live' => 'Live Casino'],
        'sports' => ['sports' => 'Sports Betting'],
        'local' => ['local' => 'Local Games'],
        'p2p' => ['p2p' => 'P2P Games'],
        'casual' => ['casual' => 'Casual Games'],
    ];

    // Start output buffering
    ob_start();

    // Only render tabs & sections if user is NOT admin or contributor
    if (current_user_can('administrator') || current_user_can('contributor')) {
?>
        <style>
            .tab-icon {
                width: clamp(18px, 3vw, 20px);
                height: clamp(18px, 3vw, 20px);
                object-fit: contain;
                transition: transform 0.2s ease;
            }

            h2 {
                color: #a566ff;
                font-weight: 600;
                font-size: clamp(1.1rem, 2.5vw, 1.2rem);
            }

            .tabs {
                display: flex;
                gap: clamp(0.5rem, 1.5vw, 1rem);
                margin-bottom: clamp(1rem, 2vw, 1.5rem);
                flex-wrap: wrap;
                justify-content: flex-start;
            }

            .item {
  
}

            .tab {
                min-width: 207px;
                height: clamp(40px, 8vw, 48px);
                background: linear-gradient(0, rgba(0, 0, 0, 0.2) 0%, #2D1A5D 0%);
                border: 1px solid rgba(168, 85, 247, 0.4);
                padding: 16px;
                font-size: 16px;
                color: #7644CE;
                cursor: pointer;
                display: flex;
                align-items: center;
                gap: 8px;
                position: relative;
                text-align: center;
                white-space: nowrap;
                transition: background-color 0.3s ease, color 0.3s ease, box-shadow 0.3s ease;
                font-family: 'Poppins', sans-serif;
                height: 64px;
            }

            .tab:hover,.tab.active {
               background: linear-gradient(
    90deg,
    rgba(37, 32, 49, 0.72),
    rgba(118, 68, 206, 0.72)
  ), rgba(0, 0, 0, 0.2);
                border-color: #7644ce;
                box-shadow: 0 0 8px rgba(118, 68, 206, 0.4);
                color: #fff;
            }

            .tab svg,
            .tab img {
                width: 32px;
                height: 32px;
                flex-shrink: 0;
            }

            .section {
                background-color: rgba(35, 20, 75, 0.7);
                border-radius: 1rem;
                box-shadow: 0 0 16px rgba(103, 58, 183, 0.3);
                padding: 1px;
                margin-bottom: 32px;
                overflow: hidden;
            }

            .section-header {
                background: linear-gradient(90deg, #7d3dfc, #985eff);
                color: #fff;
                padding: clamp(0.8rem, 2vw, 1rem) clamp(1rem, 2.5vw, 1.25rem);
                font-weight: 600;
                display: flex;
                justify-content: space-between;
                align-items: center;
                cursor: pointer;
                transition: background 0.3s ease;
                user-select: none;
                font-size: 24px;
                font-family: 'Poppins', sans-serif;
            }

            .section-header:hover {
                background: linear-gradient(90deg, #956dfd, #be95ff);
            }

            .section-header .chevron {
                transition: transform 0.3s ease;
                width: clamp(16px, 2.5vw, 18px);
                height: clamp(16px, 2.5vw, 18px);
                fill: white;
            }

            .section.open .section-header .chevron {
                transform: rotate(180deg);
            }

            .section-content {
                display: flex;
                flex-wrap: wrap;
                gap: 16px;
            }


            .provider-card {
                background: rgba(23, 23, 23, 0.6);
                border: 1px solid #6B4EBD;
                border-radius: 0.75rem;
                height: clamp(60px, 12vw, 70px);
                transition: all 0.3s ease;
                box-shadow: 0 0 0 transparent;
                cursor: pointer;
                width: 21.541%;
                height: 120px;
                box-sizing: border-box;
            }
            .provider-card a,
            .provider-card a:visited {
                display: flex;
                justify-content: center;
                align-items: center;
                width: 100%;
                height: 100%;
                padding: 20px;
                box-sizing: border-box;
                text-decoration: none;
            }

            .agqa-api-not-filled {
                position: relative;
            }

            .agqa-api-not-filled::after {
                content: "API not filled in";
                position: absolute;
                top: 8px;
                right: 8px;
                display: flex;
                align-items: center;
                justify-content: center;
                color: #fff;
                padding: 4px 12px;
                border-radius: 16px;
                background-color: #FF4D4F;
                min-width: 114px;
                height: 26px;
                font-size: 12px;
                box-sizing: border-box;
            }

            .provider-card:hover {
                background: linear-gradient(121.44deg, rgba(193, 52, 214, 0.7) -42.05%, rgba(0, 0, 0, 0.7) 67.24%, rgba(210, 57, 233, 0.7) 166.5%);
                border: 2px solid #a566ff;
            }

            .provide-card-img {
                width: 122px;
                height: 69px;
                display: flex;
                justify-content: center;
                align-items: center;
                line-height: .6;
            }

            .provider-card img {
                max-width: 122px;
                max-height: 69px;
                object-fit: contain;
                filter: drop-shadow(0 0 2px #7a61ffcc);
                transition: transform 0.2s ease;
            }

            .CP {
                font-family: 'Poppins', sans-serif;
            }

            .section-title {
                grid-column: span 100%;
                font-family: 'Poppins', sans-serif;
                font-weight: 600;
                color: #d6b4ff;
                user-select: none;
                color: #fff;
                display: inline-block;
            }

            .section-body {
                overflow: hidden;
                max-height: 0;
                transition: max-height 0.4s ease, padding 0.3s ease;
                padding: 24px 24px 29px;
            }

            .section-body h2{
                margin-bottom: 24px;
            }

            .section.open .section-body {
                max-height: 1000px;
            }

            .custom-chevron {
                transition: transform 0.3s ease;
                transform-origin: center;
                width: clamp(25px, 4vw, 30px);
            }

            .mt {
                margin-top: clamp(-30px, -5vw, -35px);
            }

            .fz {
                font-size: clamp(24px, 5vw, 30px);
                color: #c770fe;
            }

            .heading-divider {
                border: none;
                border-top: 1px solid #666;
                opacity: 0.4;
                margin-bottom: clamp(0.8rem, 2vw, 1rem);
            }

            .button-bar {
                display: flex;
                justify-content: flex-end;
                margin-bottom: clamp(0.8rem, 2vw, 1.25rem);
            }

            .add-category-button {
                color: white;
                border: none;
                cursor: pointer;
                transition: background-color 0.3s ease;
                font-family: 'Poppins', sans-serif;
            }

            /* Mobile (≤768px) */
            @media screen and (max-width: 768px) {
                .tabs {
                    gap: 0.5rem;
                    justify-content: center;
                }

                .tab {
                    width: clamp(100px, 28vw, 120px);
                    height: clamp(36px, 10vw, 40px);
                    font-size: clamp(9px, 2.2vw, 10px);
                    padding: 0 0.5rem;
                }

                .tab svg,
                .tab img {
                    width: clamp(16px, 4vw, 18px);
                    height: clamp(16px, 4vw, 18px);
                }

                .provider-card {
                    height: clamp(50px, 15vw, 60px);
                    padding: 0.8rem;
                }

                .provider-card img {
                    max-height: clamp(40px, 10vw, 50px);
                }

                .section-title {
                    font-size: clamp(16px, 4vw, 18px);
                    margin-bottom: 24px
                }

                .section-header {
                    font-size: clamp(16px, 4vw, 18px);
                    padding: 0.8rem 1rem;
                }

                .fz {
                    font-size: clamp(20px, 5.5vw, 24px);
                }

                .add-category-button {
                    padding: 8px 20px 8px 12px;
                    font-size: clamp(14px, 3.5vw, 16px);
                }
            }

            /* Tablet (769px - 1024px) */
            @media screen and (min-width: 769px) and (max-width: 1024px) {
                .tabs {
                    gap: 0.8rem;
                }

                .tab {
                    width: clamp(130px, 20vw, 140px);
                    height: clamp(42px, 7vw, 46px);
                    font-size: clamp(10px, 1.8vw, 11px);
                }

                .provider-card {
                    height: clamp(60px, 10vw, 65px);
                }

                .provider-card img {
                    max-height: clamp(45px, 8vw, 50px);
                }

                .section-title {
                    font-size: clamp(18px, 3vw, 20px);
                }

                .section-header {
                    font-size: clamp(18px, 3vw, 20px);
                }
            }
        </style>

        <div class="p-6 max-w-7xl mx-auto">
            <h1 class="text-2xl font-semibold mb-2 text-purple-400 select-none fzz">Game Categories</h1>
            <hr class="heading-divider" />
            <!-- Right-aligned button below line -->
            <div class="filter-container">
                <div class="filter-area">
                    <form action="#">
                        <input type="search" name="filter-search" id="filter-search" placeholder="Search Providers...">
                        <div class="filter-select">
                            <input type="hidden" name="filter-select-hidden" class="agqa-filter-select-hidden">
                            <button class="filter-select-title">
                                <span class="filter-default-text">selcet Role</span>
                                <span class="filter-selected-text"></span>
                            </button>
                            <div class="filter-select-list">
                                <ul>
                                    <li>New Game Categories</li>
                                    <li>API Not Filled in</li>
                                    <li>All</li>
                                </ul>
                            </div>
                        </div>
                        <button type="submit" class="filter-select-button"><span>Search</span></button>
                    </form>
                </div>
                <div class="agqa-popup-form-ctn">
                    <div class="button-bar1">
                        <button class="add-category-button gradient-btn"><img src="<?php echo AGQA_URL ?>assets/images/plus-icon.svg" alt="">
                            Add New Categories</button>
                        <div class="agqa-popup-form">
                            <div class="agqa-popup-form-inner">
                                <div class="popup-form-cross-icon"></div>
                                <form action="#">
                                    <div class="agqa-popup-form-title">
                                        <h2>Add new Categories</h2>
                                    </div>
                                    <div class="agqa-popup-form-field required">
                                        <label for="provider-name"><span>*</span> Provider Name</label>
                                        <input type="text" name="provider-name" id="provider-name" placeholder="Description">
                                    </div>
                                    <div class="agqa-popup-form-field required">
                                        <label for="budget">Budget</label>
                                        <select name="budget" id="budget">
                                            <option value="Select Plan" selected disabled>Slect Plan</option>
                                            <option value="Sale">Sale</option>
                                            <option value="Revenue">Revenue</option>
                                        </select>
                                    </div>
                                    <div class="agqa-popup-form-field required">
                                        <label for="select-role"><span>*</span> Game Type</label>
                                        <div class="agqa-popup-form-multi-select" id="select-role">
                                            <button type="button" class="agqa-popup-form-button">
                                                <span class="default-text">Select Category</span>
                                                <span class="selected-dropdown-item"></span>
                                            </button>
                                            <div class="agqa-popup-form-select">
                                                <ul>
                                                    <li data-value="slot">Slot</li>
                                                    <li data-value="table-games">Table Games</li>
                                                    <li data-value="live-casino">Live Casino</li>
                                                    <li data-value="sportsbook">Sportsbook</li>
                                                    <li data-value="esports">eSports</li>
                                                    <li data-value="virtual-sports">Virtual Sports</li>
                                                    <li data-value="cockfight">Cockfight</li>
                                                    <li data-value="fishing">Fishing</li>
                                                    <li data-value="lottery">Lottery</li>
                                                    <li data-value="number-games">Number Games</li>
                                                    <li data-value="poker">Poker</li>
                                                    <li data-value="p2p">P2P</li>
                                                    <li data-value="crash-games">Crash Games</li>
                                                    <li data-value="arcade-mini-games">Arcade / Mini Games</li>
                                                    <li data-value="keno-bingo">Keno / Bingo</li>
                                                </ul>
                                            </div>
                                            <div class="selected-tags"></div>
                                            <!-- Hidden input to store selected values as CSV -->
                                            <input type="hidden" name="select-role" class="selected-values" />
                                        </div>
                                    </div>
                                    <div class="agqa-popup-form-field">
                                        <label for="upload-file">Logo</label>
                                        <button type="submit" class="upload-file-button">
                                            Upload Logo
                                        </button>
                                        <input type="hidden" name="upload-file" class="upload-file" />
                                    </div>
                                    <div class="agqa-popup-form-field agqa-popup-form-buttons d-flex">
                                        <input type="button" value="Cancel">
                                        <input type="submit" value="Submit">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="tabs" role="tablist" aria-label="Game categories tabs">
                <?php
                $categories = [
                    'all'    => 'All',
                    'casino' => 'Casino Games',
                    'sports' => 'Sports',
                    'local'  => 'Local Games',
                    'p2p'    => 'P2P Games',
                    'casual' => 'Casual Games',
                ];

                foreach ($categories as $key => $label) {
                    $active = ($atts['category'] === $key) ? 'active' : '';
                    $selected = ($atts['category'] === $key) ? 'true' : 'false';
                    $tabindex = ($atts['category'] === $key) ? '0' : '-1';
                    echo "<button class='tab $active' role='tab' id='tab-$key' aria-controls='panel-$key' aria-selected='$selected' tabindex='$tabindex'>";
                    echo $tab_icons[$key] . $label;
                    echo "</button>";
                }
                ?>
            </div>

            <?php foreach ($categories as $key => $label) : ?>
                <section id="panel-<?php echo $key; ?>" role="tabpanel" tabindex="0" aria-labelledby="tab-<?php echo $key; ?>"
                    <?php echo ($atts['category'] !== $key) ? 'hidden' : ''; ?>>
                    <?php if ($key === 'all') : ?>
                        <?php foreach ($category_sections as $cat_key => $sections) : ?>
    <!-- Category Heading -->
    <h2 class="category-heading"><?php echo ucfirst($cat_key); ?></h2>

    <?php foreach ($sections as $sec_key => $sec_label) : ?>
        <div class="section open" id="sec-<?php echo $sec_key; ?>">
            <!-- Accordion header -->
            <div class="section-header" role="button" tabindex="0" aria-expanded="true">
                <?php echo $sec_label; ?>
                <button class="button agqa-status-toggle"
                    style="background: transparent !important; padding: 0; padding-left: 10px;">
                    <img src="<?php echo $arrow_image_url; ?>" alt="Arrow Icon"
                        class="custom-chevron" width="20" height="20" />
                </button>
            </div>

            <!-- Wrapper includes heading + content -->
            <div class="section-body">
                <h2><a href="/api-revenue-share-lookup/" class="section-title">Common Providers</a></h2>
                <div class="section-content">
                    <?php foreach ($providers[$sec_key] as $provider) : ?>
                        <div class="provider-card" title="<?php echo esc_attr($provider['name']); ?> Provider">
                            <a href="https://wiki.101.games/api-revenue-share-lookup/" class="agqa-new-label agqa-api-not-filled">
                                <div class="provide-card-img">
                                    <img src="<?php echo esc_url($image_base_url . $provider['img']); ?>"
                                        alt="<?php echo esc_attr($provider['alt']); ?>"
                                        onerror="this.style.filter='grayscale(1)'; this.style.opacity='0.6';" />
                                </div>
                            </a>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
<?php endforeach; ?>
                    <?php else : ?>
                        <?php foreach ($category_sections[$key] as $sec_key => $sec_label) : ?>
                            <div class="section open" id="sec-<?php echo $sec_key; ?>">
                                <!-- Accordion header -->
                                <div class="section-header" role="button" tabindex="0" aria-expanded="true">
                                    <?php echo $sec_label; ?>
                                    <button class="button agqa-status-toggle"
                                        style="background: transparent !important; padding: 0; padding-left: 10px;">
                                        <img src="<?php echo $arrow_image_url; ?>" alt="Arrow Icon"
                                            class="custom-chevron" width="20" height="20" />
                                    </button>
                                </div>

                                <!-- Wrapper includes heading + content -->
                                <div class="section-body">
                                    <h2><a href="/api-revenue-share-lookup/" class="section-title">Common Providers</a></h2>
                                    <div class="section-content">
                                        <?php foreach ($providers[$sec_key] as $provider) : ?>
                                            <div class="provider-card" title="<?php echo esc_attr($provider['name']); ?> Provider">
                                                <a href="/api-revenue-share-lookup/">
                                                    <img src="<?php echo esc_url($image_base_url . $provider['img']); ?>"
                                                        alt="<?php echo esc_attr($provider['alt']); ?>"
                                                        onerror="this.style.filter='grayscale(1)'; this.style.opacity='0.6';" />
                                                </a>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </section>
            <?php endforeach; ?>
        </div>

        <script>
            // const tabs = document.querySelectorAll(".tab");
            // const panels = document.querySelectorAll("[role='tabpanel']");

            // // Tab Switching Logic
            // tabs.forEach(tab => {
            //     tab.addEventListener('click', () => {
            //         // Remove active from all tabs
            //         tabs.forEach(t => {
            //             t.classList.remove('active');
            //             t.setAttribute("aria-selected", "false");
            //             t.setAttribute("tabindex", "-1");
            //         });

            //         // Hide all panels
            //         panels.forEach(p => p.hidden = true);

            //         // Activate selected tab
            //         tab.classList.add('active');
            //         tab.setAttribute("aria-selected", "true");
            //         tab.setAttribute("tabindex", "0");

            //         // Show corresponding panel
            //         const panelId = tab.getAttribute("aria-controls");
            //         const panel = document.getElementById(panelId);
            //         panel.hidden = false;
            //         panel.focus();
            //     });

            //     // Keyboard navigation
            //     tab.addEventListener('keydown', e => {
            //         let index = Array.prototype.indexOf.call(tabs, e.currentTarget);
            //         if (e.key === "ArrowRight") {
            //             e.preventDefault();
            //             let next = tabs[(index + 1) % tabs.length];
            //             next.focus();
            //         } else if (e.key === "ArrowLeft") {
            //             e.preventDefault();
            //             let prev = tabs[(index - 1 + tabs.length) % tabs.length];
            //             prev.focus();
            //         }
            //     });
            // });

            const title = document.querySelector('.filter-select-title');
            const body = document.querySelector('.filter-select-body');

            if (title && body) {
                Object.assign(body.style, {
                    overflow: 'hidden',
                    maxHeight: '0',
                    display: 'none',
                    transition: 'max-height 0.3s ease'
                });

                title.addEventListener('click', () => {
                    const isActive = title.classList.toggle('active');

                    if (isActive) {
                        body.style.display = 'block';
                        body.style.maxHeight = body.scrollHeight + 'px';
                    } else {
                        body.style.maxHeight = '0';
                        setTimeout(() => (body.style.display = 'none'), 300);
                    }
                });
            }
        </script>
<?php
    } else {
        // Placeholder for non-admin/contributor users
        echo '<p class="text-center text-gray-400 py-6 select-none">Restricted access for non-admin users.</p>';
    }

    return ob_get_clean();
}
// No search results Html
?>
<!-- <div class="no-found-result align-center">
<div class="no-found-result-icon">
    <img src="<?php echo AGQA_URL ?>assets/images/search-forund-icon.svg" alt="Search No result">
</div>
<div class="no-found-result-text">
    <h2>Nothing matched your search</h2>
</div>
</div> -->
<?php 
// Register the shortcode
add_shortcode('game_categories', 'game_categories_shortcode');
?>

