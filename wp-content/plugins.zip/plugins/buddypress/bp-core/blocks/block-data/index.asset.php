<?php return array('dependencies' => array('lodash', 'wp-api-fetch', 'wp-data'), 'version' => 'ff1f42bcce71e0d2d8b1');
