<?php
namespace ElementsKit;

class Elementskit_Menu_Walker extends \ElementsKit_Lite\ElementsKit_Menu_Walker {
	//
}
