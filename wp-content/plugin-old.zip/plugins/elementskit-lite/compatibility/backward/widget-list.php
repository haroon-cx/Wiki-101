<?php

namespace ElementsKit_Lite\Helpers;

defined( 'ABSPATH' ) || exit;

class Widget_List extends \ElementsKit_Lite\Config\Widget_List {
	//
}
