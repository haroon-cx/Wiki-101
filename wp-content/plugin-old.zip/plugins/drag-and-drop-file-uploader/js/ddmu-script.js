jQuery(document).ready(function($) {
    // Show the drag-and-drop area when button is clicked
    $('#show-ddmu-area').on('click', function() {
        $('#ddmu-drop-area').toggle();  // Toggle visibility of the drag-and-drop area
    });

    // Handle drag over event
    $('#ddmu-drop-area').on('dragover', function(e) {
        e.preventDefault();
        e.stopPropagation();
        $(this).addClass('dragging');
    });

    $('#ddmu-drop-area').on('dragleave', function(e) {
        e.preventDefault();
        e.stopPropagation();
        $(this).removeClass('dragging');
    });

    // Handle drop event
    $('#ddmu-drop-area').on('drop', function(e) {
        e.preventDefault();
        e.stopPropagation();
        $(this).removeClass('dragging');
        
        var files = e.originalEvent.dataTransfer.files;
        handleFileUpload(files);
    });

    // Handle file input change
    $('#ddmu-file-input').on('change', function(e) {
        var files = e.target.files;
        handleFileUpload(files);
    });

    // Upload files via AJAX
    function handleFileUpload(files) {
        var formData = new FormData();
        $.each(files, function(i, file) {
            formData.append('file', file);
        });

        // Add nonce to form data
        formData.append('action', 'ddmu_handle_upload');
        formData.append('nonce', ddmu_nonce.nonce); // Add nonce here

        // Show loading message
        $('#ddmu-response').html('<p>Uploading...</p>');

        // AJAX request to handle the upload
        $.ajax({
            url: ajaxurl, // WordPress AJAX handler
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false, // Don't set contentType as FormData automatically handles it
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    $('#ddmu-response').html('<p>Upload successful! File URL: ' + response.url + '</p>');
                } else {
                    $('#ddmu-response').html('<p>' + response.message + '</p>');
                }
            },
            error: function(xhr, status, error) {
                // Log the error for debugging
                console.log(xhr.responseText);
                $('#ddmu-response').html('<p>Something went wrong. Please try again.</p>');
            }
        });
    }
});
