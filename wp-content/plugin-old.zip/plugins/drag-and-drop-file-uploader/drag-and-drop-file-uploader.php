<?php
/*
Plugin Name: Drag and Drop File Uploader
Plugin URI: https://example.com
Description: A drag-and-drop file uploader for WordPress.
Version: 1.0
Author: Your Name
Author URI: https://example.com
*/

// Enqueue necessary scripts and styles
function ddmu_enqueue_scripts() {
    wp_enqueue_script('jquery');
    wp_enqueue_script('jquery-ui-widget');
    wp_enqueue_script('jquery-ui-sortable');

    // Enqueue custom JavaScript for drag-and-drop handling
    wp_enqueue_script('ddmu-script', plugin_dir_url(__FILE__) . 'js/ddmu-script.js', array('jquery'), null, true);

    // Localize the AJAX URL for the script to use
    wp_localize_script('ddmu-script', 'ajaxurl', admin_url('admin-ajax.php'));
    wp_localize_script('ddmu-script', 'ddmu_nonce', array('nonce' => wp_create_nonce('ddmu_nonce_action')));

    // Enqueue styles for the drag-and-drop area
    wp_enqueue_style('ddmu-style', plugin_dir_url(__FILE__) . 'css/ddmu-style.css');
}
add_action('wp_enqueue_scripts', 'ddmu_enqueue_scripts');

// Shortcode to display the drag-and-drop area
function ddmu_display_uploader() {
    ob_start();
    ?>
    <!-- Button to open drag and drop area -->
    <button id="show-ddmu-area" class="button">Click to Upload Files</button>

    <!-- Drag and drop file input area (Initially hidden) -->
    <div id="ddmu-drop-area" class="ddmu-drop-area" style="display:none;">
        <p>Drag and drop your files here or click to select files.</p>
        <input type="file" id="ddmu-file-input" multiple>
    </div>

    <div id="ddmu-response"></div>
    <?php
    return ob_get_clean();
}
add_shortcode('drag_and_drop_uploader', 'ddmu_display_uploader');

// Handle file upload via AJAX
function ddmu_handle_upload() {
    // Verify nonce
    if ( !isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'ddmu_nonce_action') ) {
        echo json_encode(array('status' => 'error', 'message' => 'Nonce verification failed.'));
        wp_die();
    }

    // Proceed with file upload
    if ( !empty($_FILES['file']) ) {
        $uploaded_file = $_FILES['file'];
        $upload = wp_handle_upload($uploaded_file, array('test_form' => false));

        if ( isset($upload['url']) ) {
            echo json_encode(array('status' => 'success', 'url' => $upload['url']));
        } else {
            echo json_encode(array('status' => 'error', 'message' => 'Upload failed.'));
        }
    }

    wp_die();
}
add_action('wp_ajax_ddmu_handle_upload', 'ddmu_handle_upload');
add_action('wp_ajax_nopriv_ddmu_handle_upload', 'ddmu_handle_upload');
?>
